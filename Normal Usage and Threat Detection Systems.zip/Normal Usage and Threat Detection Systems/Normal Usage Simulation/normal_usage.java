class normal_usage implements model{
	double usageVal;// a system's usage value at a point in time
	network_usage net_usag;// network behavior;
	user_behavior u_bev;//user behavior;
	device_usage device_usag;// avearge behavior of a mobile device on the networrk;
	memory_usage memory_usag;
	cpu_usage cpu_usag;
	program_usage program_usag;
	host_usage host_usag;
	double net_usag_time; // how long the system functions
	usage_modeller math_modeller;
	normal_usage(){
		net_usag=new network_usage(); 
		u_bev=new user_behavior();
		device_usag=new device_usage();
		memory_usag=new memory_usage();
		cpu_usag=new cpu_usage();
		program_usag=new program_usage();
		host_usag=new host_usage();
		math_modeller=new usage_modeller(4);
	}
	public static void main(String args[]) throws InterruptedException{
		normal_usage usage=new normal_usage();
		int min=1;
		int time=min*60*1000;
		LearnSysProcess p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13;
		p1=new LearnSysProcess("learn session_usage",usage.u_bev.x1,time,1,0);
		p1.start();
		p2=new LearnSysProcess("learn auth_usage",usage.u_bev.x2,time,1,0);
		p2.start();
		p5=new LearnSysProcess("learn memory_usage",usage.memory_usag,time,1,0);
		p5.start();
		p6=new LearnSysProcess("learn cpu_usage",usage.cpu_usag,time,1,0);
		p6.start();
		p10=new LearnSysProcess("learn server",usage.net_usag.server_usag,time,1,0);
		p10.start();
		p11=new LearnSysProcess("learn port_usage",usage.net_usag.port_usag,time,1,0);
		p11.start();
		p8=new LearnSysProcess("learn program_usage",usage.program_usag,time,1,0);
		p8.start();
		p1.join();
		p2.join();
		p5.join();
		p6.join();
		p10.join();
		p11.join();
		p8.join();
		p3=null;
		// check if processes p1 and p2 are complete then
		if(!p1.isAlive()&&!p2.isAlive()){
			p3=new LearnSysProcess("learn user_behavior",usage.u_bev,time,1,0);
			p3.start();
		}
		p4=null;
		p7=null;
		// check if processes p1,p5, and p6 are complete then
		if(!p1.isAlive()&&!p5.isAlive()&&!p6.isAlive()){
			usage.device_usag.battery_usag.set_memory_usage(usage.memory_usag);
			usage.device_usag.battery_usag.set_session_usage(usage.u_bev.x1);
			usage.device_usag.battery_usag.set_cpu_usage(usage.cpu_usag);
			p4=new LearnSysProcess("learn battery_usag",usage.device_usag.battery_usag,time,1,0);
			p4.start();
			p4.join();
			p7=new LearnSysProcess("learn device_usag",usage.device_usag,time,1,0);
			p7.start();
		}
		p3.join();
		p7.join();
		// check if process p5 is complete then
		if(!p5.isAlive()){
			usage.host_usag.set_memory_usage(usage.memory_usag);
		}
		// check if process p6 is complete then
		if(!p6.isAlive()){
			usage.host_usag.set_cpu_usage(usage.cpu_usag);
		}
		// check if process p8 is complete then
		if(!p8.isAlive()){
			usage.host_usag.set_program_usage(usage.program_usag);
		}
		// check if process p1 is complete then
		if(!p1.isAlive()){
			usage.host_usag.set_session_usage(usage.u_bev.x1);
		}
		p9=null;
		// check if processes p1,p5,p6, and p8 are complete then
		if(!p1.isAlive()&&!p5.isAlive()&&!p6.isAlive()&&!p8.isAlive()){
			usage.net_usag.set_host_usage(usage.host_usag);
			p9=new LearnSysProcess("learn host_usage",usage.net_usag.host_usag,time,1,0);
			p9.start();
			p9.join();
		}
		p12=null;
		// check if processes p9,p10 and p11 are complete then
		if(!p9.isAlive()&&!p10.isAlive()&&!p11.isAlive()){
			p12=new LearnSysProcess("learn network_usage",usage.net_usag,time,1,0);
			p12.start();
			p12.join();
		}
		p13=null;
		// check if processes p9,p10,p11,p1,p2 and p3 are complete then
		if(!p9.isAlive()&&!p10.isAlive()&&!p11.isAlive()&&!p1.isAlive()&&!p2.isAlive()&&!p3.isAlive()){
			p13=new LearnSysProcess("learn system usage",usage,time,1,0);
			p13.start();
		}

		double x_vals[]=new double[4];
		x_vals[0]=9;
		x_vals[1]=7;
		x_vals[2]=54;
		x_vals[3]=43;
		usage.math_modeller.sample_x_set(x_vals);
		usage.math_modeller.sample_y(87);
		usage.math_modeller.queue_sample();
		
		x_vals[0]=9;
		x_vals[1]=7;
		x_vals[2]=54;
		x_vals[3]=43;
		usage.math_modeller.sample_x_set(x_vals);
		usage.math_modeller.sample_y(87);
		usage.math_modeller.queue_sample();
		
		usage.math_modeller.end_modeller=true;
		usage_stats ustats=usage.math_modeller.get_usage_stats();
		x_set avg_xset=usage.math_modeller.average_x_set;
		x_vals=avg_xset.x_set;
		System.out.println("mean 1: "+x_vals[0]);
		System.out.println("mean 2: "+x_vals[1]);
		System.out.println("mean 3: "+x_vals[2]);
		System.out.println("mean 4: "+x_vals[3]);
	}
	public double computeval(){
		return 0;
	}
	public double findchange(){
		return 0;
	}
	public void learnsys(int t){
		int timer=1;
		while(t>=timer){
			net_usag.learnsys(t);
			try {
	            Thread.sleep(1000);
	        }catch (InterruptedException e){
	            e.printStackTrace();
	        }
			timer++;
			if(timer==t){
				try{
					Thread.yield();
				}
				catch(Exception e){
					
				}
			}
		}
	}
	public Object findrelationship(){
		return null;
	}
	public void monitor(int t){
			int timer=0;
		while(timer<t){
			try{
				net_usag.monitor(t);
			}
			catch(Exception e){
				
			}
		}
		timer++;
	}
	public void showalarm(String info){
		System.out.println(info);
	}
	public void haltprocess(){
	}
	public void predictvals(){
	}
}