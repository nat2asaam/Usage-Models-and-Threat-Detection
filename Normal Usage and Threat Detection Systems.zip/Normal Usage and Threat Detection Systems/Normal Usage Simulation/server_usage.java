class server_usage implements model{
	usage_modeller math_modeller;
	double usageVal;// a system's usage value at a point in time
	double x1;//number of host connected
	double x2;// cpu time being spent
	double x3; //memory  space being used
	double c1; // average proccesses running
	double c2; // average cpu time used within a time frame
	double c3;// average memory space used within a time frame
	public double computeval(){
		return 0;
	}
	public double findchange(){
		return 0;
	}
	public void learnsys(int t){
		System.out.println("learning server usage ...");
	}
	public Object findrelationship(){
		return null;
	}
	public void monitor(int t){
	}
	public void showalarm(String info){
		System.out.println(info);
	}
	public void haltprocess(){
	}
	public void predictvals(){
	}
}