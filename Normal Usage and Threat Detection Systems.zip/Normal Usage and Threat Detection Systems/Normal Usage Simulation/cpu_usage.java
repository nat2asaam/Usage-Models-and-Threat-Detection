class cpu_usage implements model{
	usage_modeller math_modeller;
	double usageVal;// a system's usage value at a point in time
	double x1;//number of progrms running
	double x2;// number of system processes running
	double y;// amount of CPU power  being used per second
	double c1;// average CPU power for programs
	double c2;// max CPU power being used for running programs
	double c3;//min CPU powerbeing used for running programs
	double c4; // average CPU power for processes;
	double c5;// max CPU power being used forrunning processes
	double c6;// min CPU power being used for for running processes
	cpu_usage(){
		
	}
	public double computeval(){
		return 0;
	}
	public double findchange(){
		return 0;
	}
	public void learnsys(int t){
		System.out.println("learning cpu usage ...");
	}
	public Object findrelationship(){
		return null;
	}
	public void monitor(int t){
	}
	public void showalarm(String info){
		System.out.println(info);
	}
	public void haltprocess(){
	}
	public void predictvals(){
	}
}