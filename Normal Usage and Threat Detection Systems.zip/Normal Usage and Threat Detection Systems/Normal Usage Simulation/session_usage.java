import java.util.*;
class session_usage implements model{
	usage_modeller math_modeller;
	double usageVal;// a system's usage value at a point in time
	double x1;// size of data accumulated
	double x2;//number of user actions
	double y;// time spent before session expires
	double c1;//average user behavior
	double c2;// average  size of data accumulated
	double c3;// average time spent before session expires
	double x_set[];// for computing usage value
	session_usage(){
		math_modeller=new usage_modeller(2);// for independent variables of size 2 (0-1)
		x1=0;
		x2=0;
		y=0;
		x_set=new double[2];
	}
	public void capture_sample(){
		Random rand=new Random();
		x1=Math.round(rand.nextDouble()*100);// 0 to 100 kb
		x2=Math.round(rand.nextDouble()*100);// 0 to 100 actions such as clicks
		y=Math.round(rand.nextDouble()*90);//0 to 90 minutes
	}
	public void set_x(double x_set[]){
		this.x_set=x_set;
	}
	public void set_sample(){
		double x_set[]=new double[2];
		x_set[0]=x1;
		x_set[1]=x2;
		math_modeller.sample_x_set(x_set);
		math_modeller.sample_y(y);
		math_modeller.queue_sample();
	}
	public double computeval(){
		//usageVal=a value  determined using x_set from the relationship determined.
		return usageVal;
	}
	public double findchange(){
		return 0;
	}
	public void learnsys(int t){
		System.out.println("learning session usage ...");
		capture_sample();
		set_sample();		
	}
	public Object findrelationship(){
		return null;
	}
	public void monitor(int t){
		
	}
	public void showalarm(String info){
		System.out.println(info);
	}
	public void haltprocess(){
	}
	public void predictvals(){
	}

}