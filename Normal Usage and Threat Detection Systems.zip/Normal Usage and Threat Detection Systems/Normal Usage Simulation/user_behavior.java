import java.util.*;
class user_behavior implements model{
	usage_modeller math_modeller;
	double usageVal;// a system's usage value at a point in time
	int n;// number of user actions such as no. of clicks per session
	session_usage x1;// behavior of user session;
	auth_usage x2;// behavior of user authentication
	user_behavior(){
		n=0;
		x1=new session_usage();
		x2=new auth_usage();
		math_modeller=new usage_modeller(2);// for independent variables of size 2 (0-1)
	}
	double s1;//computed user session usage
	double s2;// computed authentication usage
	int c1;// avearge sessionusage
	int c2;// avearge authentication behavior
	public void capture_sample(){
		Random rand=new Random();
		double k[]=new double[4];
		k[0]=Math.round(rand.nextDouble()*100);// 0 to 100 kbps
		k[1]=Math.round(rand.nextDouble()*100);// 0 to 100 kbps
		k[2]=Math.round(rand.nextDouble()*5);// 0 to 5 kb
		k[3]=Math.round(rand.nextDouble()*5);// 0 to 5 kb
		x1.set_x(k);
		double p[]=new double[2];
		p[0]=Math.round(rand.nextDouble()*100);// 0 to 100 kb
		p[1]=Math.round(rand.nextDouble()*100);// 0 to 100 actions such as clicks
		x2.set_x(p);
		s1=x1.computeval();// computed usage val for x1
		s2=x2.computeval();// computed usage val for x2
		n=Math.round(rand.nextInt()*100);//0 to 100 actions
	}
	public void set_sample(){
		double x_set[]=new double[2];
		x_set[0]=s1;
		x_set[1]=s2;
		math_modeller.sample_x_set(x_set);
		math_modeller.sample_y(n);
		math_modeller.queue_sample();
	}
	public double computeval(){
		return 0;
	}
	public double findchange(){
		return 0;
	}
	public void learnsys(int t){
		System.out.println("learning user_behavior usage ...");
		capture_sample();
		set_sample();
	}
	public Object findrelationship(){
		return null;
	}
	public void monitor(int t){
		
	}
	public void showalarm(String info){
		System.out.println(info);
	}
	public void haltprocess(){
	}
	public void predictvals(){
	}
}