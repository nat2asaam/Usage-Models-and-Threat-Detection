/*
Y=a+bX;
*/
class Fnx{
	double a;
	double b;
	double average;
	double r;
	public Fnx(double a,double b){
		this.a=a;
		this.b=b;
	}
	public double getValue(double x){
		return a+(b*x);
	}
	public double findChange(double y){
		return y-average;
	}
	public void setAverage(double average){
		this.average=average;
	}
	public void setR(double r){
		this.r=r;
	}
	public String toString(){
		String rel=a+"+"+b+"X";
		return rel;
	}
	
}